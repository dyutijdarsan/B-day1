# MINNIEVERSE 💗

A mobile-friendly birthday website for Manvi. The four photos are embedded in `index.html`, so you do not need to upload a separate images folder.

## Publish on GitHub Pages (free)
1. Create a **new public repository** on GitHub (for example, `minnieverse`).
2. Extract this ZIP on your phone/computer.
3. Upload the **contents of this folder** to the repository's root. Make sure `index.html` and `.nojekyll` are directly visible on the repository's main page (not inside another folder).
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch `main` and folder `/(root)`, then tap **Save**.
7. Wait a few minutes, then open `https://YOUR-USERNAME.github.io/minnieverse/` (replace `YOUR-USERNAME` with your GitHub username).

## Important privacy note
GitHub Pages sites are public. Anyone who has the link may view the site and its embedded photos. Do not use GitHub Pages for private photos or real secrets/passwords.
