# MINNIEVERSE 💗
Upload `index.html` and `.nojekyll` to a new GitHub repository (root), then Settings → Pages → Deploy from a branch → main → /(root) → Save.
Or drag this folder onto netlify.com/drop for an instant link.
Note: public hosting means anyone with the link can see the embedded photos.
